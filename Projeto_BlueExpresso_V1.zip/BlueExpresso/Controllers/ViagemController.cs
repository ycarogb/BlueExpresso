﻿using BlueExpresso.API;
using BlueExpresso.Models;
using BlueExpresso.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BlueExpresso.Controllers
{
    [Produces(MediaTypeNames.Application.Json)]
    [Consumes(MediaTypeNames.Application.Json)]
    [ApiController]
    [Route("Viagem")]
    public class ViagemController : APIBaseController
    {
        IViagemService _service;

        public ViagemController(IViagemService service)
        {
            _service = service;
        }

        /// <summary>
        /// "Retorna uma lista de tickets de viagem exitentes no banco de dados"
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpGet]
        public IActionResult Index() => ApiOk(_service.GetAll());

        /// <summary>
        /// "Retorna um ticket de viagem específico de acordo com o id informado"
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Authorize]
        [Route("{id}")]
        [HttpGet]
        public IActionResult Index(int id) =>
            _service.Get(id) == null ?
            ApiNotFound("Viagem não encontrada!") :
            ApiOk(_service.Get(id));

        /// <summary>
        /// "Retorna um ticket de viagem aleatório existente no banco de dados"
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [Route("aleatorio")]
        [HttpGet]
        public IActionResult gerarRandom()
        {
            List<Viagem> listaViagens = _service.GetAll().ToList();
            Random aleatorio = new Random();
            return ApiOk(listaViagens[aleatorio.Next(listaViagens.Count)]);
        }

        /// <summary>
        /// "Cria um novo ticket de viagem e adiciona ao banco de dados"
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [AuthorizeRoles(RoleType.Admin)]
        [HttpPost]
        public IActionResult Create([FromBody] Viagem viagem)
        {
            viagem.createdById = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
            return _service.Create(viagem) ?
            ApiOk("Viagem criada com sucesso!") :
            ApiNotFound("Erro ao inserir viagem!");
        }

        /// <summary>
        /// "Atualiza as informações de um ticket de viagem existente"
        /// </summary>
        /// <returns></returns>
        /// 
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [AuthorizeRoles(RoleType.Admin)]
        [HttpPut]
        public IActionResult Update([FromBody] Viagem viagem)
        {
            viagem.createdById = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
            return _service.Update(viagem) ?
            ApiOk("Viagem atualizada com sucesso!") :
            ApiNotFound("Erro ao atualizar viagem!");
        }

        /// <summary>
        /// "Apaga um ticket de viagem existente no banco de dados"
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [AuthorizeRoles(RoleType.Admin)]
        [Route("{id}")]
        [HttpDelete]
        public IActionResult Delete(int id) =>
            _service.Delete(id) ?
            ApiOk("Viagem apagada com sucesso!") :
            ApiNotFound("Erro ao apagar viagem!");

        /// <summary>
        /// "Retorna todas as viagens inseridas por um usuário"
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [AllowAnonymous]
        [Route("ProductsByRole/{role?}")]
        [HttpGet]
        public IActionResult ViagemByUserRole(string role)
        {
            return ApiOk(_service.ViagemByUserRole(role));
        }
    } 
}

