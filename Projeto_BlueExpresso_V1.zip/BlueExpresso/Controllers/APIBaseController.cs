﻿using BlueExpresso.API;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlueExpresso.Controllers
{
    //Definindo respostas padrão para a aplicação
    public class APIBaseController : ControllerBase
    {
        protected OkObjectResult ApiOk<T>(T Results) =>
            Ok(CustomResponse(Results));

        protected OkObjectResult ApiOk(string Message = "") =>
            Ok(CustomResponse(true, Message));

        protected NotFoundObjectResult ApiNotFound(string Message = "") =>
            NotFound(CustomResponse(false, Message));

        protected BadRequestObjectResult ApiBadRequest<T>(T Results, string Message = "") =>
            BadRequest(CustomResponse(Results, false, Message));

        APIResponse<T> CustomResponse<T>(T Results, bool succeed = true, string message = "") =>
            new APIResponse<T>()
            {
                Results = Results,
                Succeed = succeed,
                Message = message
            };

        APIResponse<string> CustomResponse(bool succeed = true, string message = "") =>
            new APIResponse<string>()
            {
                Succeed = succeed,
                Message = message
            };
    }
}
