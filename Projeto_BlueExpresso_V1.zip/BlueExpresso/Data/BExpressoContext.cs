﻿using BlueExpresso.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlueExpresso.Data
{
    public class BExpressoContext : IdentityDbContext
    {
        public BExpressoContext(DbContextOptions<BExpressoContext> options) : base(options) { }

        public DbSet<Viagem> Viagens { get; set; }

    }
}
