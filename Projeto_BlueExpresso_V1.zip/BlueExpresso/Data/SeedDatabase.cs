﻿using BlueExpresso.Data;
using BlueExpresso.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Consultorio.Data
{
    public static class SeedDatabase
    {
        public static void Initialize(IHost app)
        {
            using (var scope = app.Services.CreateScope())
            {
                var serviceProvider = scope.ServiceProvider;
                var context = serviceProvider.GetRequiredService<BExpressoContext>();
                context.Database.Migrate(); // update-database

                int qtde_registros = 15;
                string[] listaNomes = new string[] { "João", "Mauro", "José", "Roberto", "Paulo", "Ana", "Paula", "Maria", "Bruna", "Juma" };
                string[] listaSobrenomes = new string [] {"Silva", "Santos", "Moura", "Ferreira", "Vasconcelos", "Batalha", "da Costa", "Gonçalves", "Souza", "Sauro"};
                string[] origens = new string [] { "Rio de Janeiro", "São Paulo", "Santos", "Petrópolis" };
                string[] destinos = new string[] { "Cabo Frio", "Itaipava", "Niterói", "Nilópolis" };

                if (context.Viagens.Any())
                {
                    return;
                }

                for (int i = 0; i < qtde_registros; i++)
                {
                    Random aleatorio = new Random();
                    var nomeCompleto = $"{listaNomes[aleatorio.Next(0, listaNomes.Length)]} {listaSobrenomes[aleatorio.Next(0, listaSobrenomes.Length)]}";

                    var data = new DateTime(2021, 1, 1);
                    int dias = (DateTime.Today - data).Days;
                    data = data.AddDays(aleatorio.Next(dias));

                    string cpf = aleatorio.Next(111111111, 999999999).ToString();

                    var origem = $"{origens[aleatorio.Next(0, origens.Length)]}";
                    var destino = $"{destinos[aleatorio.Next(0, destinos.Length)]}";

                    context.Viagens.AddRange(
                        new Viagem
                        {
                            Cliente = nomeCompleto,
                            Data = data,
                            Origem = origem,
                            Destino = destino,
                            CPF = cpf
                        });
                }

                context.SaveChanges();
            }
        }
    }
}