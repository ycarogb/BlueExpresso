﻿using BlueExpresso.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlueExpresso.Services
{
    public interface IViagemService
    {
        List<Viagem> GetAll();
        Viagem Get(int id);
        bool Create(Viagem viagem);
        bool Update(Viagem viagem);
        bool Delete(int id);
        List<Viagem> ViagemByUserRole(string role);

    }
}
