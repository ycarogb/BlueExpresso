﻿using BlueExpresso.Data;
using BlueExpresso.Models;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlueExpresso.Services
{
    public class ViagemService : IViagemService
    {
        BExpressoContext _context;

        public ViagemService(BExpressoContext context)
        {
            _context = context;
        }
        public bool Create(Viagem viagem)
        {
            try
            {
                _context.Add(viagem);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Delete(int id)
        {
            try
            {
                _context.Remove(this.Get(id));
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public Viagem Get(int id)
        {
            return _context.Viagens.FirstOrDefault(p => p.Id == id);
        }
    

        public List<Viagem> GetAll()
        {
            return _context.Viagens.ToList();
        }

        public bool Update(Viagem viagem)
        {
            if (!_context.Viagens.Any(p => p.Id == viagem.Id))
                throw new Exception("Viagem não existente!!");

            try
            {
                _context.Update(viagem);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Viagem> ViagemByUserRole(string getRole)
        {
            var lquery1 = from viagem in _context.Set<Viagem>()
                            join user in _context.Set<IdentityUser>()
                            on viagem.createdById equals user.Id
                            join userRoles in _context.Set<IdentityUserRole<string>>()
                            on user.Id equals userRoles.UserId
                            join role in _context.Set<IdentityRole>()
                            on userRoles.RoleId equals role.Id
                            where role.Name.ToUpper() == getRole
                            select new Viagem()
                            {
                                Id = viagem.Id,
                                Cliente = viagem.Cliente,
                                CPF = viagem.CPF,
                                Origem = viagem.Origem,
                                Destino = viagem.Destino,
                                Data = viagem.Data,
                                createdBy = viagem.createdBy,
                                updatedBy = viagem.updatedBy
                            };
            return lquery1.ToList();
        }
    }
}
