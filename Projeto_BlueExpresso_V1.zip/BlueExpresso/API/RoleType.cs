﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlueExpresso.Models
{
    public enum RoleType
    {
        Admin,
        Common
    }
}
